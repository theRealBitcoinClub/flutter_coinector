package cash.bitcoinmap.coinector

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

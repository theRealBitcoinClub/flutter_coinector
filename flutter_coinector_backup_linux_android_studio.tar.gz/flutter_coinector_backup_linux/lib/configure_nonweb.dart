/*void configureApp() {
  // No-op.
}
*/

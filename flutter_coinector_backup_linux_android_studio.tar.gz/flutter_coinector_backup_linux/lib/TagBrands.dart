// Identifier b

class TagBrands {
  static final tagBrands = const {
    "TRBC - The Real Bitcoin Club",
    "Anypay",
    "GoCrypto",
    "Satoshi's Angels",
    "Panmoni",
    "Binance",
    "Salamantex",
    "CryptoBuyer",
    "XPay",
    "Bitcoin.jp",
    "Bitcoin.com",
    "Bitcoinstad Arnhem",
    "Coinmap.org"
  };
}

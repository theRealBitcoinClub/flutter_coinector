import 'package:Coinector/SearchRouterApp.dart';
import 'package:flutter/cupertino.dart';

main() {
  runApp(SearchRouterApp());
}

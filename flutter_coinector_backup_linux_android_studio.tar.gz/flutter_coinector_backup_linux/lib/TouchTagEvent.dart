abstract class TouchTagEvent{
  hasHit(String tag);
}
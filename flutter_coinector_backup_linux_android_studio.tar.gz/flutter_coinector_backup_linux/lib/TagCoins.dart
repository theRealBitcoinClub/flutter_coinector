// Identifier w

class TagCoins {
  static final tagCoins = const {
    "BCH",
    "DASH",
    "BTC",
    "USDT",
    "BUSD",
    "FlexUSD"
  };
}

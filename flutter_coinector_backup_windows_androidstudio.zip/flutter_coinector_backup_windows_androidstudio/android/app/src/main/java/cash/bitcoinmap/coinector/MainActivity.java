package cash.bitcoinmap.coinector;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
  //This class is not necessary while the AndroidManifest links directly to FlutterActivity

  /*@Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    GeneratedPluginRegistrant.registerWith(getFlutterEngine());
  }*/
}
